from .internal.gaml import (
    GamlObj,
    GamlSet
)